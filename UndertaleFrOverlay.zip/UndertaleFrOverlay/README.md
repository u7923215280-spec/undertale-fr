# Undertale FR Overlay

App Android indépendante : capture d'écran (MediaProjection) -> OCR chinois (ML Kit)
-> traduction chinois→français (ML Kit) -> image (Canvas) -> affichage flottant (WindowManager)
à côté du texte original. Le jeu n'est jamais modifié.

## Compiler
1. Ouvrir le dossier dans Android Studio (Koala ou plus récent, JDK 17). Laisser la synchro Gradle se faire (internet requis).
2. Build > Build APK(s), ou Run sur un téléphone (Android 8.0+).

## Utiliser
1. Bouton 1 : autoriser l'affichage par-dessus les autres apps.
2. Bouton 2 : télécharger le modèle de traduction (une seule fois, internet).
3. Bouton 3 : démarrer (accepter la capture d'écran).
4. Bouton 4 : lancer le jeu. L'interrupteur active/désactive la traduction (activée par défaut).

Si le jeu ne se lance pas depuis le bouton 4, corriger GAME_PACKAGE dans MainActivity.kt
(et la balise <queries> du manifeste) avec le vrai nom de package.

package fr.overlay.undertalefr

import android.util.LruCache
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import kotlinx.coroutines.tasks.await

/** Traduction chinois -> français via ML Kit, avec cache pour ne pas retraduire les mêmes phrases. */
class TranslationEngine {
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.CHINESE)
            .setTargetLanguage(TranslateLanguage.FRENCH)
            .build()
    )
    private val cache = LruCache<String, String>(1000)

    suspend fun ensureModel() {
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
    }

    suspend fun translate(text: String): String? {
        cache.get(text)?.let { return it }
        val result = translator.translate(text).await()
        if (result.isNotBlank()) cache.put(text, result)
        return result.ifBlank { null }
    }

    fun close() = translator.close()
}

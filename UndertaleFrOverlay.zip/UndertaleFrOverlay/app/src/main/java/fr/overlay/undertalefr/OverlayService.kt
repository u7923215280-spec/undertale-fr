package fr.overlay.undertalefr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.util.Size
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/**
 * Service au premier plan :
 *  capture d'écran (MediaProjection) -> OCR chinois -> traduction FR -> image -> affichage flottant.
 * Les textes chinois du jeu ne sont jamais modifiés : l'overlay est une fenêtre séparée.
 */
class OverlayService : Service() {

    private lateinit var settings: SettingsStore
    private lateinit var windowManager: WindowManager
    private lateinit var recognizer: TextRecognizer
    private lateinit var engine: TranslationEngine

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    @Volatile private var imageReader: ImageReader? = null
    private var overlayView: OverlayView? = null
    private var loopJob: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var captureSize = Size(0, 0)
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        engine = TranslationEngine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // Android 14 : startForeground (type mediaProjection) AVANT getMediaProjection.
        startAsForeground()

        if (running) return START_NOT_STICKY
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startCapture(code, data)
            running = true
        } catch (e: Exception) {
            Log.e(TAG, "Impossible de démarrer la capture", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Traduction Undertale", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Undertale FR Overlay")
            .setContentText("Traduction visuelle en cours")
            .setOngoing(true)
            .addAction(0, "Arrêter", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        // Obligatoire depuis Android 14 : enregistrer un callback avant createVirtualDisplay.
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        projection = proj

        val screen = screenSize()
        captureSize = captureDims(screen)
        val reader = ImageReader.newInstance(
            captureSize.width, captureSize.height, PixelFormat.RGBA_8888, 2
        )
        imageReader = reader
        virtualDisplay = proj.createVirtualDisplay(
            "UtryFrCapture",
            captureSize.width, captureSize.height,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )

        addOverlay()
        loopJob = scope.launch { mainLoop() }
    }

    private fun addOverlay() {
        val view = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        windowManager.addView(view, lp)
        overlayView = view
    }

    // ---------------------------------------------------------------- boucle principale

    private suspend fun mainLoop() {
        var lastSig = 0L
        var processedSig = Long.MIN_VALUE
        var lastKey = ""

        while (scope.isActive) {
            delay(POLL_MS)
            val reader = imageReader ?: continue

            // Interrupteur des paramètres : si désactivé, on vide l'overlay et on ne fait rien.
            if (!settings.enabled) {
                reader.acquireLatestImage()?.close()
                if (lastKey.isNotEmpty()) {
                    lastKey = ""
                    processedSig = Long.MIN_VALUE
                    overlayView?.setItems(emptyList())
                }
                continue
            }

            adaptToRotation()

            val image = reader.acquireLatestImage() ?: continue
            val bmp = try {
                image.toBitmap()
            } catch (e: Exception) {
                Log.w(TAG, "Conversion image échouée", e)
                null
            } finally {
                image.close()
            }
            if (bmp == null) continue

            // On n'analyse que quand l'écran est stable (texte fini de s'afficher) et nouveau.
            val sig = signature(bmp)
            val stable = sig == lastSig
            lastSig = sig
            if (!stable || sig == processedSig) {
                bmp.recycle()
                continue
            }
            processedSig = sig

            try {
                val items = analyze(bmp)
                val key = items.joinToString("|") { "${it.first}@${it.second}" }
                if (key != lastKey) {
                    lastKey = key
                    val built = items.map { it.third }
                    withContext(Dispatchers.Main) { overlayView?.setItems(built) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Analyse échouée", e)
            } finally {
                bmp.recycle()
            }
        }
    }

    /** OCR + traduction. Retourne (texte source, boîte, item à afficher). */
    private suspend fun analyze(bmp: Bitmap): List<Triple<String, Rect, OverlayView.Item>> {
        val screen = screenSize()
        val sx = screen.width.toFloat() / bmp.width
        val sy = screen.height.toFloat() / bmp.height
        val textSize = max(resources.displayMetrics.scaledDensity * 11f, min(screen.width, screen.height) * 0.035f)

        val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
        val out = ArrayList<Triple<String, Rect, OverlayView.Item>>()
        val placed = ArrayList<Rect>()

        val blocks = result.textBlocks.sortedBy { it.boundingBox?.top ?: 0 }
        for (block in blocks) {
            val box = block.boundingBox ?: continue
            val src = block.text.replace("\n", "").replace(" ", "").trim()
            if (src.length < 2 || !CJK.containsMatchIn(src)) continue

            val fr = engine.translate(src) ?: continue
            val screenBox = Rect(
                (box.left * sx).toInt(), (box.top * sy).toInt(),
                (box.right * sx).toInt(), (box.bottom * sy).toInt()
            )
            val maxW = min(
                (screen.width * 0.6f).toInt(),
                max(screenBox.width(), (screen.width * 0.35f).toInt())
            )
            val image = BubbleRenderer.render(fr, maxW, textSize)
            val pos = place(screenBox, image.width, image.height, screen, placed)
            placed.add(Rect(pos.first.toInt(), pos.second.toInt(),
                pos.first.toInt() + image.width, pos.second.toInt() + image.height))
            out.add(Triple(src, screenBox, OverlayView.Item(image, pos.first, pos.second)))
        }
        return out
    }

    /** Place l'image juste sous le texte original (ou au-dessus si pas de place), sans chevauchement. */
    private fun place(box: Rect, w: Int, h: Int, screen: Size, placed: List<Rect>): Pair<Float, Float> {
        val gap = 6 * resources.displayMetrics.density
        val x = box.left.toFloat().coerceIn(0f, max(0, screen.width - w).toFloat())
        var y = box.bottom + gap
        if (y + h > screen.height) y = box.top - h - gap
        if (y < 0f) y = max(0, screen.height - h).toFloat()

        var tries = 0
        while (tries < 8) {
            val r = Rect(x.toInt(), y.toInt(), x.toInt() + w, y.toInt() + h)
            if (placed.none { Rect.intersects(it, r) }) break
            y += h + gap
            if (y + h > screen.height) break
            tries++
        }
        return x to y
    }

    // ---------------------------------------------------------------- utilitaires capture

    private fun screenSize(): Size {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = windowManager.maximumWindowMetrics.bounds
            Size(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(dm)
            Size(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun captureDims(screen: Size): Size {
        val scale = min(1f, MAX_CAPTURE_SIDE / max(screen.width, screen.height).toFloat())
        return Size(
            max(2, (screen.width * scale).toInt()),
            max(2, (screen.height * scale).toInt())
        )
    }

    /** Si l'écran pivote, on redimensionne l'affichage virtuel (sans en recréer un : Android 14). */
    private fun adaptToRotation() {
        val wanted = captureDims(screenSize())
        if (wanted == captureSize) return
        val old = imageReader
        val newReader = ImageReader.newInstance(wanted.width, wanted.height, PixelFormat.RGBA_8888, 2)
        virtualDisplay?.resize(wanted.width, wanted.height, resources.displayMetrics.densityDpi)
        virtualDisplay?.surface = newReader.surface
        imageReader = newReader
        captureSize = wanted
        old?.close()
    }

    private fun Image.toBitmap(): Bitmap {
        val plane = planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val full = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, width, height)
        full.recycle()
        return cropped
    }

    /** Signature très légère de l'image (grille de 48x27 pixels) pour détecter les changements. */
    private fun signature(bmp: Bitmap): Long {
        var h = 1125899906842597L
        val stepX = max(1, bmp.width / 48)
        val stepY = max(1, bmp.height / 27)
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                h = 31 * h + bmp.getPixel(x, y)
                x += stepX
            }
            y += stepY
        }
        return h
    }

    override fun onDestroy() {
        loopJob?.cancel()
        scope.cancel()
        try { overlayView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        overlayView = null
        virtualDisplay?.release()
        imageReader?.close()
        try { projection?.stop() } catch (_: Exception) {}
        recognizer.close()
        engine.close()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "UtryFrOverlay"
        const val ACTION_STOP = "fr.overlay.undertalefr.STOP"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "utry_fr_overlay"
        private const val NOTIF_ID = 42
        private const val POLL_MS = 500L
        private const val MAX_CAPTURE_SIDE = 1600f
        private val CJK = Regex("[\\u4E00-\\u9FFF]")

        fun start(context: Context, resultCode: Int, data: Intent) {
            val i = Intent(context, OverlayService::class.java)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}

package fr.overlay.undertalefr

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.ceil
import kotlin.math.max

/** Transforme un texte français en IMAGE (Bitmap) dessinée avec Canvas. */
object BubbleRenderer {

    fun render(text: String, maxWidth: Int, textSizePx: Float): Bitmap {
        val pad = (textSizePx * 0.5f).toInt()
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = textSizePx
        }
        val innerMax = max(50, maxWidth - 2 * pad)
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, paint, innerMax)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .build()

        var lineMax = 0f
        for (i in 0 until layout.lineCount) lineMax = max(lineMax, layout.getLineWidth(i))

        val w = ceil(lineMax).toInt() + 2 * pad
        val h = layout.height + 2 * pad
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val radius = pad.toFloat()
        val rect = RectF(1f, 1f, w - 1f, h - 1f)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 12, 12, 24) }
        canvas.drawRoundRect(rect, radius, radius, bg)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = max(2f, textSizePx * 0.06f)
        }
        canvas.drawRoundRect(rect, radius, radius, border)

        canvas.translate(pad.toFloat(), pad.toFloat())
        layout.draw(canvas)
        return bmp
    }
}

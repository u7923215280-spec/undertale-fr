package fr.overlay.undertalefr

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import fr.overlay.undertalefr.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var settings: SettingsStore

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                OverlayService.start(this, r.resultCode, data)
                status("Traduction démarrée. Lancez maintenant le jeu (bouton 4).")
            } else {
                status("Autorisation de capture d'écran refusée.")
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        settings = SettingsStore(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // Interrupteur : activé par défaut, désactivable/réactivable à tout moment.
        b.switchTranslation.isChecked = settings.enabled
        b.switchTranslation.setOnCheckedChangeListener { _, checked ->
            settings.enabled = checked
            status(if (checked) "Traduction activée." else "Traduction désactivée.")
        }

        b.btnOverlayPerm.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        b.btnDownload.setOnClickListener {
            status("Téléchargement du modèle de traduction…")
            lifecycleScope.launch {
                val engine = TranslationEngine()
                try {
                    engine.ensureModel()
                    status("Modèle chinois → français prêt (utilisable hors-ligne).")
                } catch (e: Exception) {
                    status("Échec du téléchargement : ${e.message}")
                } finally {
                    engine.close()
                }
            }
        }

        b.btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                status("Autorisez d'abord l'affichage par-dessus les autres apps (bouton 1).")
                return@setOnClickListener
            }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }

        b.btnLaunchGame.setOnClickListener {
            val intent = packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
            if (intent != null) startActivity(intent)
            else status("Jeu introuvable ($GAME_PACKAGE). Ouvrez-le manuellement.")
        }

        b.btnStop.setOnClickListener {
            OverlayService.stop(this)
            status("Traduction arrêtée.")
        }
    }

    private fun status(msg: String) {
        b.txtStatus.text = msg
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        // Nom de package supposé d'après le nom du fichier APK. À corriger si besoin.
        const val GAME_PACKAGE = "com.cgoat.utry"
    }
}

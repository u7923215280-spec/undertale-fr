package fr.overlay.undertalefr

import android.content.Context

/** Réglages persistants. La traduction est ACTIVE par défaut dès le premier lancement. */
class SettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("settings", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) {
            prefs.edit().putBoolean(KEY_ENABLED, value).apply()
        }

    private companion object {
        const val KEY_ENABLED = "translation_enabled"
    }
}

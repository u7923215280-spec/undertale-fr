package fr.overlay.undertalefr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View

/** Vue plein écran transparente qui dessine uniquement les images de traduction. */
class OverlayView(context: Context) : View(context) {

    data class Item(val bitmap: Bitmap, val x: Float, val y: Float)

    @Volatile
    private var items: List<Item> = emptyList()

    fun setItems(list: List<Item>) {
        items = list
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        for (item in items) canvas.drawBitmap(item.bitmap, item.x, item.y, null)
    }
}
